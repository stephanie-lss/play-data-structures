package com.offer.interview35;

/**
 * @author LiSheng
 * @date 2020/5/12 22:18
 */
class Node {
    int val;
    Node next;
    Node random;

    public Node(int val) {
        this.val = val;
        this.next = null;
        this.random = null;
    }
}
