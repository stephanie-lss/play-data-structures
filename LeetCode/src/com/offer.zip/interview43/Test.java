package com.offer.interview43;

/**
 * @author LiSheng
 * @date 2020/7/15 10:48
 */
public class Test {
    public static void main(String[] args) {
        System.out.println('1' - '0');
    }
}
